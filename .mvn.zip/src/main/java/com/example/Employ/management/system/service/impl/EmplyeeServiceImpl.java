package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.entity.Employee;
import com.example.Employ.management.system.exception.ResourceNotFoundException;
import com.example.Employ.management.system.mspper.EmployeeMapper;
import com.example.Employ.management.system.repository.EmployeRipository;
import com.example.Employ.management.system.service.EmployeService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class EmplyeeServiceImpl implements EmployeService{

    private EmployeRipository employeRipository;
    @Override
    public Employee createEmploye(EmployeeDto employeDto) {

        Employee employee= EmployeeMapper.mapToEmployeeDto(employeDto);
        Employee savedEmployee=employeRipository.save(employee);

        return savedEmployee;
    }


    @Override
    public Employee getEmployeeById(Long employeeId) {
        return employeRipository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee is not exist with this id :"+employeeId));

    }

    @Override
    public List<EmployeeDto> getAllEmployees() {
        List<Employee> employees= employeRipository.findAll();
        return employees.stream().map((employee) ->EmployeeMapper.mapToEmployeeDto(employee)).collect(Collectors.toList());
    }

    @Override
    public EmployeeDto updateEmployee(EmployeeDto updatedEmployee) {
        Employee employee =employeRipository.findById(updatedEmployee.getId()).orElseThrow(
                () -> new ResourceNotFoundException("Employee is not exist with this given ID:"+updatedEmployee.getId())
        );

        employee.setFirstName(updatedEmployee.getFirstname());
        employee.setLastName(updatedEmployee.getLastname());
        employee.setEmail(updatedEmployee.getEmail());

        Employee updateEmployeeObj=employeRipository.save(employee);

        return EmployeeMapper.mapToEmployeeDto(updateEmployeeObj);
    }

    @Override
    public void deleteEmployee(Long employeeId) {
        Employee employee =employeRipository.findById(employeeId).orElseThrow(
                () -> new ResourceNotFoundException("Employee is not exist with this given ID:"+employeeId)
        );
        employeRipository.deleteById(employeeId);

    }


}
