package com.example.Employ.management.system.service;

import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface EmployeService {


    Employee createEmploye(EmployeeDto employeDto);
    Employee getEmployeeById(Long employeeId);
    List<EmployeeDto>getAllEmployees();
    EmployeeDto updateEmployee(EmployeeDto updatedEmployee);
    void deleteEmployee(Long employeeId);

}
  