package com.example.Employ.management.system.controller;


import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.entity.Employee;
import com.example.Employ.management.system.service.EmployeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employe")


public class EmployeeController {
    @Autowired
    private EmployeService employeService;

    //Build add Employee Rest Api
    @PostMapping
    public ResponseEntity<Employee>createEmployee(@RequestBody EmployeeDto employeeDto){
        Employee savedEmployee=employeService.createEmploye(employeeDto);
        return new ResponseEntity<>(savedEmployee,HttpStatus.CREATED);
    }

    //Building Get Employee Rest Api
    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable("id")Long employeeId){
        Employee employeeDto =employeService.getEmployeeById(employeeId);
        return employeeDto;
    }

    //Building Get All Employee Rest Api

    @GetMapping
        public ResponseEntity<List<EmployeeDto>> getAllEmployees(){
        List<EmployeeDto> employees =employeService.getAllEmployees();
        return ResponseEntity.ok(employees);

    }

    //Building Get Update Employee Rest Api
    @PutMapping("/update")
    public ResponseEntity<EmployeeDto>updateEmployee(@RequestBody EmployeeDto updatedEmployee){
        EmployeeDto employeeDto=employeService.updateEmployee(updatedEmployee);
        return ResponseEntity.ok(employeeDto);
    }

    //Building Get Delete Employee Rest Api
    @DeleteMapping("/{id}")
    public ResponseEntity<String>deleteEmployee(@PathVariable("id") Long employeeId){
        employeService.deleteEmployee(employeeId);
        return ResponseEntity.ok("Employee deleted Successfully.");
    }

}
