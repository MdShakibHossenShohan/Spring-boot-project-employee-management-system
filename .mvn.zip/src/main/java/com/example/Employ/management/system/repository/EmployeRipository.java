package com.example.Employ.management.system.repository;

import com.example.Employ.management.system.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;




    public interface EmployeRipository extends JpaRepository<Employee,Long> {
}

