package com.example.Employ.management.system.mspper;

public @interface Mappings {
}
