package com.example.Employ.management.system.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class ProjectDto {
    private long id;

    private String projectTitel;

    private Integer startDate;

    private Integer endDate;

    private String status;

}
