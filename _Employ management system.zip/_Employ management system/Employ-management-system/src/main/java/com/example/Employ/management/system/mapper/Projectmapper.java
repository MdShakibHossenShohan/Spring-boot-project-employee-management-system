package com.example.Employ.management.system.mapper;

import com.example.Employ.management.system.dto.ProjectDto;
import com.example.Employ.management.system.entity.Project;

public class Projectmapper {

    public static Project maptoProject (ProjectDto projectDto){
        return new  Project(
                projectDto.getId(),
                projectDto.getProjectTitel(),
                projectDto.getStartDate(),
                projectDto.getEndDate(),
                projectDto.getStatus()

        );
    }

    public  static ProjectDto maptoProjectDto (Project project){
        return new ProjectDto(
                project.getId(),
                project.getProjectTittel(),
                project.getStartDate(),
                project.getEndDate(),
                project.getStatus()
        );
    }
}
