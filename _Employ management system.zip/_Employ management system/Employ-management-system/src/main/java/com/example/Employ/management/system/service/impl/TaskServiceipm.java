package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.TaskDto;
import com.example.Employ.management.system.entity.Project;
import com.example.Employ.management.system.entity.Task;
import com.example.Employ.management.system.exception.ResourceNotFoundException;
import com.example.Employ.management.system.mapper.Projectmapper;
import com.example.Employ.management.system.mapper.Taskmapper;
import com.example.Employ.management.system.repository.TaskRipository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service

public class TaskServiceipm implements TaskService{

    @Autowired
    private TaskRipository taskRipository;

    @Override
    public TaskDto createTask(TaskDto taskDto) {

        Task task = Taskmapper.maptoTask(taskDto);
        Task saveTask = taskRipository.save(task);
        TaskDto newTaskDto = Taskmapper.maptoTaskDto(saveTask);
        return  newTaskDto;

        }

    @Override
    public List<TaskDto> getAll() {
        List<Task> allTask = taskRipository.findAll();
        return allTask.stream().map((task) -> {
            return Taskmapper.maptoTaskDto(task);
        }).collect(Collectors.toList());
    }

    @Override
    public TaskDto findById(Long id) {
        Task task = taskRipository.findById(id).orElseThrow(() -> new ResourceNotFoundException(
               "Employee is not exist with this id " + id));
        return Taskmapper.maptoTaskDto(task);
    }

    @Override
    public void deleteById(Long id) {
        Task task = taskRipository.findById(id).orElseThrow(()-> new ResourceNotFoundException(
                "Employee is not exist with this id" +id));
        taskRipository.deleteById(id);

    }

    @Override
    public TaskDto updateTask(TaskDto taskDto) {

        Task task = taskRipository.findById(taskDto.getId()).orElseThrow(()-> new ResourceNotFoundException(
                "Employee Task is not exist with this id" +taskDto.getId()));


        task.setTittel(taskDto.getTittel());
         task.setDescription(taskDto.getDescription());
         task.setAssignedTo(taskDto.getAssignedTo());
         task.setProjectId(taskDto.getProjectId());
         task.setDueDate(taskDto.getDueDate());
         task.setCreatedAt(taskDto.getCreatedAt());
         task.setUpdateAt(taskDto.getUpdateAt());


         Task saveTask =taskRipository.save(task);
         return Taskmapper.maptoTaskDto(saveTask);
    }


}
