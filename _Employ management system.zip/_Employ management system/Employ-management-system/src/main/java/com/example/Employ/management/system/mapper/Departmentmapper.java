package com.example.Employ.management.system.mapper;

import com.example.Employ.management.system.dto.DepartmentDto;
import com.example.Employ.management.system.entity.Department;

public class Departmentmapper {

    public static Department maptoDepartment (DepartmentDto departmentDto){
        return new Department(
                departmentDto.getId(),
                departmentDto.getDepartmentName(),
                departmentDto.getSalary()
        );

    }


    public static DepartmentDto maptoDepartmentDto (Department department) {
        return new DepartmentDto(
                department.getId(),
                department.getDepartmentName(),
                department.getSalary()

        );
    }


}
