package com.example.Employ.management.system.repository;

import com.example.Employ.management.system.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRipository extends JpaRepository<Task,Long> {

}
