package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.PromotionDto;

import java.util.List;

public interface PromotionService {
    PromotionDto createPromotion (PromotionDto promotionDto);

    List<PromotionDto> getAll();

    PromotionDto findById(Long id);

    void  deleteById(Long id);

    PromotionDto updatePromotion(PromotionDto promotionDto);
}
