package com.example.Employ.management.system.entity;

import jakarta.persistence.*;
import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "Promotion")

public class Promotion {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "Promotion_id")
    private Integer promotionId;

    @Column(name = "Update_salary")
    private Integer updateSalary;

    @Column(name = "Past_Department")
    private String pastDepartment;

    @Column(name = "Present_Department")
    private String presentDepartment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department")
    private Department department;

    public Promotion(Long id, Integer promotionId, Integer updateSalary, String pastDepartment, String presentDepartment) {
        this.id = id;
        this.promotionId = promotionId;
        this.updateSalary = updateSalary;
        this.pastDepartment = pastDepartment;
        this.presentDepartment = presentDepartment;


    }
}
