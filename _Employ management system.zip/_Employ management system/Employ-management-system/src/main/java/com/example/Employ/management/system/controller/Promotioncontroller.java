package com.example.Employ.management.system.controller;

import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.dto.ProjectDto;
import com.example.Employ.management.system.dto.PromotionDto;
import com.example.Employ.management.system.dto.TaskDto;
import com.example.Employ.management.system.service.impl.EmployeeService;
import com.example.Employ.management.system.service.impl.PromotionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/promotion")
public class Promotioncontroller {

    @Autowired
    private PromotionService promotionService;

  @PostMapping
  public ResponseEntity<PromotionDto> createPromotion(@RequestBody PromotionDto promotionDto){
        PromotionDto newPromotionDto = promotionService.createPromotion(promotionDto);
        return  new ResponseEntity<>(newPromotionDto,HttpStatus.CREATED);
    }
    @GetMapping
    public ResponseEntity<List<PromotionDto>> getAllPromotion(){
        List<PromotionDto> newPromotionDto =promotionService.getAll();
        return ResponseEntity.ok(newPromotionDto);

    }
    @GetMapping("{id}")
    public ResponseEntity<PromotionDto> findById(@PathVariable("id") Long id){
      PromotionDto promotionDto =promotionService.findById(id);
      return ResponseEntity.ok(promotionDto);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteById(@PathVariable("id") Long id){
      promotionService.deleteById(id);
      return ResponseEntity.ok("Deleted Successfully");
    }
    @PutMapping
    public ResponseEntity<PromotionDto> updatePromotion(@RequestBody PromotionDto promotionDto){
      PromotionDto promotion =promotionService.updatePromotion(promotionDto);
      return ResponseEntity.ok(promotion);
    }


}











