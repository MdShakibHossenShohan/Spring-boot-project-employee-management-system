package com.example.Employ.management.system.repository;

import com.example.Employ.management.system.entity.Department;
import com.example.Employ.management.system.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRipository extends  JpaRepository<Department,Long>{


}
