package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.DepartmentDto;

import java.util.List;

public interface DepartmentService {
    DepartmentDto createDepartment(DepartmentDto departmentDto);

    List<DepartmentDto> getAll();

    DepartmentDto findById(Long id);

    void deleteById(Long id);

    DepartmentDto updateDepartment(DepartmentDto departmentDto);
}

