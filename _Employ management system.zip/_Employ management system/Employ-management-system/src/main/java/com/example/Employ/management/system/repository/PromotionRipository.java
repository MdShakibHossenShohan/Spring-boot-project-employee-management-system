package com.example.Employ.management.system.repository;

import com.example.Employ.management.system.entity.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PromotionRipository extends JpaRepository<Promotion,Long> {
}
