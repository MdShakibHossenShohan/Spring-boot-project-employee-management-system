package com.example.Employ.management.system.repository;

import com.example.Employ.management.system.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRipository extends JpaRepository <Project,Long> {


}
