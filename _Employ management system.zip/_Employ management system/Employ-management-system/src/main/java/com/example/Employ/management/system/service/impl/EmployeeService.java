package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.EmployeeDto;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface EmployeeService {
    EmployeeDto createEmployee(EmployeeDto employeeDto);

    List<EmployeeDto> getAll();

    EmployeeDto getById(Long id);

    void deleteById(Long id);

    EmployeeDto updateEmployee(EmployeeDto employeeDto);



}
