package com.example.Employ.management.system.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

public class TaskDto {

    private long id;

    private String tittel;

    private String description;

    private String assignedTo;

    private Integer projectId;

    private Integer dueDate;

    private Integer createdAt;

    private Integer updateAt;

}
