package com.example.Employ.management.system.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import jakarta.persistence.Column;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor


public class DepartmentDto {

    private long Id;


    private String departmentName;


    private Integer salary;

}
