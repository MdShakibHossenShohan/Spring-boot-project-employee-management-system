package com.example.Employ.management.system.controller;

import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.dto.ProjectDto;
import com.example.Employ.management.system.repository.ProjectRipository;
import com.example.Employ.management.system.service.impl.EmployeeService;
import com.example.Employ.management.system.service.impl.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/project")

public class Projectcontroller {

    @Autowired
    private ProjectService projectService;
    @PostMapping
    public ResponseEntity<ProjectDto> createProject(@RequestBody ProjectDto projectDto){
        ProjectDto newProjectDto = projectService.createProject(projectDto);
        return new ResponseEntity<>(newProjectDto, HttpStatus.CREATED);
    }

   @GetMapping
    public ResponseEntity<List<ProjectDto>> getAllProject(){
        List<ProjectDto> newListProjectDto = projectService.getAll();
        return ResponseEntity.ok(newListProjectDto);
    }
   @GetMapping("{id}")
    public  ResponseEntity<ProjectDto> getById(@PathVariable("id") Long id){
        ProjectDto projectDto =projectService.findById(id);
        return ResponseEntity.ok(projectDto);
    }
    @DeleteMapping("{id}")
    public  ResponseEntity<String> deleteByID(@PathVariable("id") Long id){
        projectService.deleteById(id);
        return ResponseEntity.ok("Deleted successfully");

    }
    @PutMapping
    public ResponseEntity<ProjectDto>updateProject(@RequestBody ProjectDto projectDto){
        ProjectDto project = projectService.updateProject(projectDto);
        return ResponseEntity.ok(project);
    }


}
