package com.example.Employ.management.system.entity;

import jakarta.persistence.*;
import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "task")

public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "Titel")
    private String tittel;

    @Column (name = "Description")
    private String description;

    @Column (name = "Assigned_to")
    private String assignedTo;

    @Column (name = "Project_id")
    private Integer projectId;

    @Column (name = "Due_date")
    private Integer dueDate;

    @Column (name = "Created_at")
    private Integer createdAt;

    @Column (name = "Update_at")
    private Integer updateAt;


}
