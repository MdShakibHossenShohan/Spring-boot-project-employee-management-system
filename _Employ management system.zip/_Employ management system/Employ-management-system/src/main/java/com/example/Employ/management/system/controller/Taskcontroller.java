package com.example.Employ.management.system.controller;


import com.example.Employ.management.system.dto.ProjectDto;
import com.example.Employ.management.system.dto.TaskDto;
import com.example.Employ.management.system.entity.Task;
import com.example.Employ.management.system.service.impl.ProjectService;
import com.example.Employ.management.system.service.impl.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/task")

public class Taskcontroller {

    @Autowired
    private TaskService taskService;

    @PostMapping
    public ResponseEntity<TaskDto> createTask(@RequestBody TaskDto taskDto){
        TaskDto newTaskDto = taskService.createTask(taskDto);
        return new ResponseEntity<>(newTaskDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<TaskDto>> getAllTask(){
        List<TaskDto> newListDto = taskService.getAll();
        return ResponseEntity.ok(newListDto);
    }
    @GetMapping("{id}")
    public ResponseEntity<TaskDto> getById(@PathVariable("id") Long id){
        TaskDto taskDto = taskService.findById(id);
        return ResponseEntity.ok(taskDto);
    }
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteById(@PathVariable("id") Long id){
       taskService.deleteById(id);
       return ResponseEntity.ok("Deleted Successfully");
    }
    @PutMapping

    public  ResponseEntity<TaskDto> updateTask(@RequestBody TaskDto taskDto){
        TaskDto task=taskService.updateTask(taskDto);
        return  ResponseEntity.ok(task);
    }

}


