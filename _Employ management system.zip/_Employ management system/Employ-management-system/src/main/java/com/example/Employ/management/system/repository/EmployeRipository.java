package com.example.Employ.management.system.repository;

import com.example.Employ.management.system.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
    public interface EmployeRipository extends JpaRepository<Employee,Long> {
}

