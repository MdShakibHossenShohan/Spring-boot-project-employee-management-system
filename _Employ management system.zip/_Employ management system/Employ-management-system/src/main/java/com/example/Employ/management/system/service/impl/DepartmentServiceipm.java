package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.DepartmentDto;
import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.entity.Department;
import com.example.Employ.management.system.entity.Employee;
import com.example.Employ.management.system.exception.ResourceNotFoundException;
import com.example.Employ.management.system.mapper.Departmentmapper;
import com.example.Employ.management.system.mapper.Employeemapper;
import com.example.Employ.management.system.repository.DepartmentRipository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service

public class DepartmentServiceipm implements DepartmentService {

    @Autowired
   private DepartmentRipository departmentRipository;

    @Override
    public DepartmentDto createDepartment(DepartmentDto departmentDto) {
        Department department = Departmentmapper.maptoDepartment(departmentDto);
        Department saveDepartment = departmentRipository.save(department);
        DepartmentDto newDepartmentDto = Departmentmapper.maptoDepartmentDto(saveDepartment);
        return newDepartmentDto;

    }

    @Override
    public List<DepartmentDto> getAll() {
        List<Department> allDepartment = departmentRipository.findAll();
        return allDepartment.stream().map((department) -> {
            return Departmentmapper.maptoDepartmentDto(department);
        }).collect(Collectors.toList());
    }

    @Override
    public DepartmentDto findById(Long id) {
        Department department = departmentRipository.findById(id).orElseThrow(()->new ResourceNotFoundException(
                "No Department with this id"+id));
        return Departmentmapper.maptoDepartmentDto(department);
    }

    @Override
    public void deleteById(Long id) {
        Department department = departmentRipository.findById(id).orElseThrow(()->new ResourceNotFoundException(
                "No Department with this id"+id));
        departmentRipository.deleteById(id);

    }

    @Override
    public DepartmentDto updateDepartment(DepartmentDto departmentDto) {

        Department department = departmentRipository.findById(departmentDto.getId()).orElseThrow
                (()->new ResourceNotFoundException("Employee is not exist with this id" + departmentDto.getId()));

        department.setDepartmentName(departmentDto.getDepartmentName());
        department.setSalary(departmentDto.getSalary());

        Department saveDepartment = departmentRipository.save(department);
        return Departmentmapper.maptoDepartmentDto(saveDepartment);
    }

}
