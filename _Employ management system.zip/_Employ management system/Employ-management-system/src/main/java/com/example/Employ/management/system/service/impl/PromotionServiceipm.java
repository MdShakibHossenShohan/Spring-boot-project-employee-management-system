package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.ProjectDto;
import com.example.Employ.management.system.dto.PromotionDto;
import com.example.Employ.management.system.entity.Project;
import com.example.Employ.management.system.entity.Promotion;
import com.example.Employ.management.system.exception.ResourceNotFoundException;
import com.example.Employ.management.system.mapper.Projectmapper;
import com.example.Employ.management.system.mapper.PromotionMapper;
import com.example.Employ.management.system.repository.ProjectRipository;
import com.example.Employ.management.system.repository.PromotionRipository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service
public class PromotionServiceipm implements PromotionService{

    @Autowired
    private PromotionRipository promotionRipository;

    @Override
    public PromotionDto createPromotion(PromotionDto promotionDto) {
        Promotion promotion =PromotionMapper.maptoPromotion(promotionDto);
        Promotion savePromotion =promotionRipository.save(promotion);
        PromotionDto newPromotionDto = PromotionMapper.maptoPromotionDto(savePromotion);
        return newPromotionDto;
    }

    @Override
    public List<PromotionDto> getAll() {
        List<Promotion> allPromotion =promotionRipository.findAll();
        return allPromotion.stream().map((Promotion) -> {
            return PromotionMapper.maptoPromotionDto(Promotion);
       }).collect(Collectors.toList());
    }

    @Override
    public PromotionDto findById(Long id) {
        Promotion promotion = promotionRipository.findById(id).orElseThrow(() -> new ResourceNotFoundException
                ("Promoted Employee is not exist with this id " + id));
        return  PromotionMapper.maptoPromotionDto(promotion);
    }

    @Override
    public void deleteById(Long id) {
        Promotion promotion = promotionRipository.findById(id).orElseThrow(() -> new ResourceNotFoundException
                ("Promoted Employee is not exist with this id " + id));
        promotionRipository.deleteById(id);

    }

    @Override
    public PromotionDto updatePromotion(PromotionDto promotionDto) {
        Promotion promotion = promotionRipository.findById(promotionDto.getId()).orElseThrow(() -> new ResourceNotFoundException
                ("Promoted Update Employee is not exist with this id " + promotionDto.getId()));

        promotion.setPromotionId(promotionDto.getPromotionId());
        promotion.setUpdateSalary(promotionDto.getUpdateSalary());
        promotion.setPastDepartment(promotionDto.getPastDepartment());
        promotion.setPresentDepartment(promotionDto.getPresentDepartment());

        Promotion savePromotion =promotionRipository.save(promotion);
        return PromotionMapper.maptoPromotionDto(savePromotion);
    }

}




