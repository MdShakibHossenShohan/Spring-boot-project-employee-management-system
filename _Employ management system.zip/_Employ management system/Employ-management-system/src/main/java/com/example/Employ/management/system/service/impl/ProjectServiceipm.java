package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.ProjectDto;
import com.example.Employ.management.system.entity.Employee;
import com.example.Employ.management.system.entity.Project;
import com.example.Employ.management.system.exception.ResourceNotFoundException;
import com.example.Employ.management.system.mapper.Employeemapper;
import com.example.Employ.management.system.mapper.Projectmapper;
import com.example.Employ.management.system.repository.ProjectRipository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service
public class ProjectServiceipm implements ProjectService{

    @Autowired
    private ProjectRipository projectRipository;
    @Override
    public ProjectDto createProject(ProjectDto projectDto) {

        Project project = Projectmapper.maptoProject(projectDto);
        Project saveProject = projectRipository.save(project);
        ProjectDto newProjectDto =Projectmapper.maptoProjectDto(saveProject);
        return newProjectDto;
    }
    @Override
    public List<ProjectDto> getAll() {
        List<Project> allProject = projectRipository.findAll();
        return allProject.stream().map((project) -> {
            return Projectmapper.maptoProjectDto(project);
              }).collect(Collectors.toList());
    }

    @Override
    public ProjectDto findById(Long id) {
        Project project = projectRipository.findById(id).orElseThrow(() -> new ResourceNotFoundException(
                "Employee is not exist with this id " + id));
        return Projectmapper.maptoProjectDto(project);
    }

    @Override
    public void deleteById(Long id) {
        Project project = projectRipository.findById(id).orElseThrow(() -> new ResourceNotFoundException(
                "Employee is not exist with this id " + id));
        projectRipository.deleteById(id);
    }

    @Override
    public ProjectDto updateProject(ProjectDto projectDto) {

        Project project = projectRipository.findById(projectDto.getId()).orElseThrow(() -> new ResourceNotFoundException(
                "Employee is not exist with this id " + projectDto.getId() ));

             project.setProjectTittel(projectDto.getProjectTitel());
             project.setStartDate(projectDto.getStartDate());
             project.setEndDate(projectDto.getEndDate());
             project.setEndDate(projectDto.getEndDate());

        Project saveProject = projectRipository.save(project);
        return Projectmapper.maptoProjectDto(saveProject);


    }


}


