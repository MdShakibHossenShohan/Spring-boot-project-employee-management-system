package com.example.Employ.management.system.dto;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class PromotionDto {

    private long id;
    private Integer promotionId;
    private Integer updateSalary;

    private String pastDepartment;

    private String presentDepartment;

}
