package com.example.Employ.management.system.entity;

import jakarta.persistence.*;
import lombok.*;


@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "project")

public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column (name = "Project_Titel")
    private String projectTittel;

    @Column (name = "Start_Date")
    private Integer startDate;

    @Column (name = "End_Date")
    private Integer endDate;

    @Column (name = "Status")
    private String status;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task")
    private Project project;

    public Project(Long id, String projectTittel, Integer startDate,Integer endDate,String status) {
        this.id=id;
        this.projectTittel=projectTittel;
        this.startDate=startDate;
        this.endDate=endDate;
        this.status=status;
    }
}
