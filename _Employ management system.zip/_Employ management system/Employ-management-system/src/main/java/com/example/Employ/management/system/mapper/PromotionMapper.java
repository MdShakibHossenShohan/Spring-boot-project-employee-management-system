package com.example.Employ.management.system.mapper;

import com.example.Employ.management.system.dto.PromotionDto;
import com.example.Employ.management.system.entity.Promotion;

public class PromotionMapper {

    public static Promotion maptoPromotion (PromotionDto promotionDto){
        return new Promotion(
                promotionDto.getId(),
                promotionDto.getPromotionId(),
                promotionDto.getUpdateSalary(),
                promotionDto.getPastDepartment(),
                promotionDto.getPresentDepartment()

        );
    }
    public  static PromotionDto maptoPromotionDto (Promotion promotion){
        return  new PromotionDto(
                promotion.getId(),
                promotion.getPromotionId(),
                promotion.getUpdateSalary(),
                promotion.getPastDepartment(),
                promotion.getPresentDepartment()
        );
    }

}
