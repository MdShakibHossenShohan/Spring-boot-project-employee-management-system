package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.dto.ProjectDto;

import java.util.List;

public interface ProjectService {

    ProjectDto createProject (ProjectDto projectDto);
    List<ProjectDto> getAll();

    ProjectDto findById(Long id);

    void deleteById(Long id);

    ProjectDto updateProject (ProjectDto projectDto);
}
