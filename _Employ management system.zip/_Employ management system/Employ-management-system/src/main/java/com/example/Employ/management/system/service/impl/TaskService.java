package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.ProjectDto;
import com.example.Employ.management.system.dto.TaskDto;
import com.example.Employ.management.system.entity.Project;
import com.example.Employ.management.system.entity.Task;
import com.example.Employ.management.system.exception.ResourceNotFoundException;
import com.example.Employ.management.system.mapper.Projectmapper;

import java.util.List;

public interface TaskService {
    TaskDto createTask(TaskDto taskDto);

    List<TaskDto> getAll();

    TaskDto findById(Long id);

    void deleteById(Long id);

    TaskDto updateTask (TaskDto taskDto);

}


