package com.example.Employ.management.system.mapper;

import com.example.Employ.management.system.dto.TaskDto;
import com.example.Employ.management.system.entity.Task;

public class Taskmapper {

    public static Task maptoTask(TaskDto taskDto){
        return new Task(
                taskDto.getId(),
                taskDto.getTittel(),
                taskDto.getDescription(),
                taskDto.getAssignedTo(),
                taskDto.getProjectId(),
                taskDto.getDueDate(),
                taskDto.getCreatedAt(),
                taskDto.getUpdateAt()
        );
    }
    public static TaskDto maptoTaskDto(Task task){
        return new TaskDto(
                task.getId(),
                task.getTittel(),
                task.getDescription(),
                task.getAssignedTo(),
                task.getProjectId(),
                task.getDueDate(),
                task.getCreatedAt(),
                task.getUpdateAt()
        );
    }

}
