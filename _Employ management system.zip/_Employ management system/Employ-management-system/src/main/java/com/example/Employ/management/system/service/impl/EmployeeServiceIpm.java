package com.example.Employ.management.system.service.impl;

import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.entity.Employee;
import com.example.Employ.management.system.exception.ResourceNotFoundException;
import com.example.Employ.management.system.mapper.Employeemapper;
import com.example.Employ.management.system.repository.EmployeRipository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service

public class EmployeeServiceIpm implements EmployeeService{

    @Autowired
    private EmployeRipository employeRipository;

    @Override
    public EmployeeDto createEmployee(EmployeeDto employeeDto) {
        Employee employee = Employeemapper.maptoEmployee(employeeDto);
        Employee saveEmployee = employeRipository.save(employee);
        EmployeeDto newEmployeeDto = Employeemapper.maptoEmployeeDto(saveEmployee);
        return newEmployeeDto;
    }

    @Override
    public List<EmployeeDto> getAll() {
        List<Employee> allEmployee = employeRipository.findAll();
        return allEmployee.stream().map((employee) -> {
            return Employeemapper.maptoEmployeeDto(employee);
        }).collect(Collectors.toList());
    }

    @Override
    public EmployeeDto getById(Long id) {
        Employee employee = employeRipository.findById(id).orElseThrow(() -> new ResourceNotFoundException(
                "Employee is not exist with this id " + id
        ));
        return Employeemapper.maptoEmployeeDto(employee);
    }

    @Override
    public void deleteById(Long id) {
        Employee employee = employeRipository.findById(id).orElseThrow(() -> new ResourceNotFoundException(
                "Employee is not exist with this id " + id
        ));
        employeRipository.deleteById(id);

    }

    @Override
    public EmployeeDto updateEmployee(EmployeeDto employeeDto) {
        Employee employee = employeRipository.findById(employeeDto.getId()).orElseThrow(() -> new ResourceNotFoundException(
                "Employee is not exist with this id " + employeeDto.getId()
        ));
        employee.setFirstName(employeeDto.getFirstName());
        employee.setLastName(employeeDto.getLastName());
        employee.setEmail(employeeDto.getEmail());
        Employee saveEmployee = employeRipository.save(employee);
        return Employeemapper.maptoEmployeeDto(saveEmployee);
    }


























































































































}
