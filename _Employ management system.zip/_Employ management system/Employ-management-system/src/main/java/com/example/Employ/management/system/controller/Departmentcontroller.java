package com.example.Employ.management.system.controller;


import com.example.Employ.management.system.dto.DepartmentDto;
import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.service.impl.DepartmentService;
import com.example.Employ.management.system.service.impl.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/department")
public class Departmentcontroller {

    @Autowired
    private DepartmentService departmentService;
    @PostMapping
    public ResponseEntity<DepartmentDto> createDepartment(@RequestBody DepartmentDto departmentDto){
        DepartmentDto newEmployeeDto = departmentService.createDepartment(departmentDto);
        return new ResponseEntity<>(newEmployeeDto, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<DepartmentDto>> getAllEmployee(){
        List<DepartmentDto> newListDepartmentDto = departmentService.getAll();
        return ResponseEntity.ok(newListDepartmentDto);
    }


    @GetMapping("{id}")
    public  ResponseEntity<DepartmentDto> findById(@PathVariable("id") Long id){
       DepartmentDto departmentDto = departmentService.findById(id);
        return ResponseEntity.ok(departmentDto);
    }

    @DeleteMapping("{id}")
    public  ResponseEntity<String> deleteById(@PathVariable("id") Long id){
        departmentService.deleteById(id);
        return ResponseEntity.ok("Deleted successfully");
    }

    @PutMapping
    public  ResponseEntity<DepartmentDto> updateDepartment(@RequestBody DepartmentDto departmentDto){
        DepartmentDto department =departmentService.updateDepartment(departmentDto);
        return ResponseEntity.ok(department);
    }

}

