package com.example.Employ.management.system.entity;

import jakarta.persistence.*;
import jakarta.persistence.criteria.Order;
import lombok.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "department")

public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long Id;

    @Column(name = "Department_Name")
    private String departmentName;

    @Column(name = "Salary_Bdt")
    private Integer salary;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee")
    private Employee employee;

    public Department(Long id, String departmentName, Integer salary) {
        this.Id=id;
        this.departmentName=departmentName;
        this.salary=salary;
}
}





