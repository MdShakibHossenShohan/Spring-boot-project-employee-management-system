package com.example.Employ.management.system.controller;

import com.example.Employ.management.system.dto.EmployeeDto;
import com.example.Employ.management.system.entity.Employee;
import com.example.Employ.management.system.mapper.Employeemapper;
import com.example.Employ.management.system.repository.EmployeRipository;
import com.example.Employ.management.system.service.impl.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employee")
public class Employeecontroller {
    @Autowired
    private EmployeeService employeeService;
    @PostMapping
    public ResponseEntity<EmployeeDto> createEmployee(@RequestBody EmployeeDto employeeDto){
        EmployeeDto newEmployeeDto = employeeService.createEmployee(employeeDto);
        return new ResponseEntity<>(newEmployeeDto, HttpStatus.CREATED);
    }
    @GetMapping
    public ResponseEntity<List<EmployeeDto>> getAllEmployee(){
        List<EmployeeDto> newListEmployeeDto = employeeService.getAll();
        return ResponseEntity.ok(newListEmployeeDto);
    }

    @GetMapping("{id}")
    public  ResponseEntity<EmployeeDto> getById(@PathVariable("id") Long id){
        EmployeeDto employeeDto = employeeService.getById(id);
        return ResponseEntity.ok(employeeDto);
    }

    @DeleteMapping("{id}")
    public  ResponseEntity<String> deleteById(@PathVariable("id") Long id){
        employeeService.deleteById(id);
        return ResponseEntity.ok("Deleted successfully");
    }

    @PutMapping
    public ResponseEntity<EmployeeDto> updateEmployee(@RequestBody EmployeeDto employeeDto){
        EmployeeDto employee = employeeService.updateEmployee(employeeDto);
        return  ResponseEntity.ok(employee);
    }


}
